
const express = require('express');
const app = express();
const port = 3000;
const groupsData = require('./data/groups.json'); // Importing JSON data

// Route to display JSON data
app.get('/groups', (req, res) => {
  res.json(groupsData); // Sending JSON data as it is
});

// Server listening
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}/groups`);
});
