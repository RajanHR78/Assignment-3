
const express = require('express');
const app = express();
const port = 3000;

// Dummy data for demonstration
let users = [{ id: 1, name: 'John' }, { id: 2, name: 'Emma' }];

// Add a new user (POST)
app.post('/users', (req, res) => {
  const newUser = { id: users.length + 1, name: 'New User' };
  users.push(newUser);
  res.json(newUser);
});

// Update a user (PUT)
app.put('/users/:id', (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  const user = users.find(user => user.id === parseInt(id));
  if (!user) return res.status(404).json({ message: 'User not found' });
  user.name = name;
  res.json(user);
});

// Delete a user (DELETE)
app.delete('/users/:id', (req, res) => {
  const { id } = req.params;
  users = users.filter(user => user.id !== parseInt(id));
  res.sendStatus(204);
});

// Server listening
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}/users`);
});
