
const express = require('express');
const app = express();
const port = 3000;

// Route to display group names
app.get('/', (req, res) => {
  // You need to read the JSON file and send the group names
  // For simplicity, I'll assume you have the group names in an array
  const groupNames = ["Group1", "Group2", "Group3"]; // Replace this with actual data
  res.send(`<h1>Group Names</h1><ul>${groupNames.map(name => `<li>${name}</li>`).join('')}</ul>`);
});

// Server listening
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
